# Integración con Backend API - byteTECH

## Descripción

Este documento describe la integración del frontend con el backend de byteTECH a través de la API REST.

## Configuración

### Variables de Entorno

El frontend utiliza las siguientes variables de entorno:

```env
NEXT_PUBLIC_API_URL=https://api.bytetechedu.com
NODE_ENV=development
```

### Archivos de Configuración

- `lib/config.ts` - Configuración general de la aplicación
- `lib/api.ts` - Cliente HTTP para comunicarse con el backend

## Endpoints de Autenticación

### Registro de Usuario

**Endpoint:** `POST /auth/register`

**Request Body:**
```json
{
  "name": "string",
  "email": "string", 
  "password": "string",
  "is_sensei": false
}
```

**Response:**
```json
{
  "message": "User created successfully",
  "user": {
    "id": 1,
    "name": "Juan Pérez",
    "email": "juan@example.com",
    "is_sensei": false,
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z"
  }
}
```

### Login de Usuario

**Endpoint:** `POST /auth/login`

**Request Body:**
```json
{
  "email": "string",
  "password": "string"
}
```

**Response:**
```json
{
  "message": "Login successful",
  "user": {
    "id": 1,
    "name": "Juan Pérez",
    "email": "juan@example.com",
    "is_sensei": false,
    "created_at": "2024-01-01T00:00:00Z",
    "updated_at": "2024-01-01T00:00:00Z"
  }
}
```

**Cookies:**
- `access_token` - JWT token para autenticación
- `refresh_token` - JWT token para renovar sesión

### Logout

**Endpoint:** `POST /auth/logout`

**Response:**
```json
{
  "message": "Logout successful"
}
```

## Manejo de Errores

### Errores de Validación (422)

```json
{
  "detail": [
    {
      "loc": ["body", "email"],
      "msg": "Email already registered",
      "type": "value_error"
    }
  ]
}
```

### Errores de Autenticación

- **404** - Usuario no encontrado
- **401** - Contraseña incorrecta

## Uso en el Frontend

### Hook de Autenticación

```typescript
import { useAuth } from '@/hooks/useAuth'

function MyComponent() {
  const { user, isAuthenticated, login, register, logout } = useAuth()

  const handleLogin = async () => {
    const success = await login('user@example.com', 'password123')
    if (success) {
      console.log('Login exitoso')
    }
  }

  const handleRegister = async () => {
    const success = await register({
      name: 'Juan Pérez',
      email: 'juan@example.com',
      password: 'password123',
      is_sensei: false
    })
    if (success) {
      console.log('Registro exitoso')
    }
  }

  return (
    <div>
      {isAuthenticated ? (
        <div>
          <p>Bienvenido, {user?.name}</p>
          <button onClick={logout}>Cerrar sesión</button>
        </div>
      ) : (
        <div>
          <button onClick={handleLogin}>Iniciar sesión</button>
          <button onClick={handleRegister}>Registrarse</button>
        </div>
      )}
    </div>
  )
}
```

### Protección de Rutas

```typescript
import { ProtectedRoute, PublicRoute, SenseiRoute } from '@/components/auth/ProtectedRoute'

// Ruta que requiere autenticación
function DashboardPage() {
  return (
    <ProtectedRoute>
      <div>Dashboard privado</div>
    </ProtectedRoute>
  )
}

// Ruta solo para usuarios NO autenticados
function LoginPage() {
  return (
    <PublicRoute>
      <div>Página de login</div>
    </PublicRoute>
  )
}

// Ruta solo para senseis
function AdminPage() {
  return (
    <SenseiRoute>
      <div>Panel de administración</div>
    </SenseiRoute>
  )
}
```

### API Directa

```typescript
import { authApi } from '@/lib/api'

// Registro
try {
  const response = await authApi.register({
    name: "Juan Pérez",
    email: "juan@example.com",
    password: "password123",
    is_sensei: false
  })
  console.log('Usuario creado:', response.user)
} catch (error) {
  console.error('Error en registro:', error)
}

// Login
try {
  const response = await authApi.login({
    email: "juan@example.com",
    password: "password123"
  })
  console.log('Login exitoso:', response.user)
} catch (error) {
  console.error('Error en login:', error)
}

// Logout
try {
  await authApi.logout()
  console.log('Logout exitoso')
} catch (error) {
  console.error('Error en logout:', error)
}
```

## Características Implementadas

### ✅ Completado

- [x] Configuración de API con variables de entorno
- [x] Cliente HTTP con manejo de errores
- [x] Integración de registro con backend real
- [x] Integración de login con backend real
- [x] Manejo de cookies JWT
- [x] Validación de formularios
- [x] Mensajes de error específicos
- [x] Logging para debugging
- [x] Eliminación de referencias a forgot-password
- [x] Hook personalizado de autenticación (`useAuth`)
- [x] Protección de rutas (`ProtectedRoute`, `PublicRoute`, `SenseiRoute`)
- [x] Componente de logout (`LogoutButton`)
- [x] Interceptores para manejo automático de tokens
- [x] Persistencia de sesión en localStorage
- [x] Página de pruebas de autenticación (`/test-auth`)
- [x] Manejo de refresh tokens
- [x] Logout automático por expiración

### 🔄 En Progreso

- [ ] Tests de integración automatizados
- [ ] Optimización de performance
- [ ] Mejoras en UX/UI

### 📋 Pendiente

- [ ] Middleware de autenticación en Next.js
- [ ] Cache de datos de usuario
- [ ] Notificaciones push para sesiones expiradas
- [ ] Analytics de autenticación

## Debugging

Para habilitar logs de debugging, asegúrate de que `NODE_ENV=development` esté configurado.

Los logs incluyen:
- Intentos de registro/login
- Respuestas exitosas
- Errores detallados
- Información de requests/responses

## Notas Importantes

1. **Cookies HttpOnly**: Los tokens JWT se manejan automáticamente como cookies HttpOnly por el backend
2. **CORS**: El backend debe estar configurado para permitir requests desde el dominio del frontend
3. **Validación**: La validación se realiza tanto en el frontend como en el backend
4. **Compatibilidad**: Se mantiene compatibilidad con el sistema de autenticación local existente
5. **Interceptores**: Los interceptores manejan automáticamente la renovación de tokens expirados
6. **Persistencia**: Los datos del usuario se guardan en localStorage para persistencia de sesión
7. **Protección**: Las rutas están protegidas automáticamente según el nivel de autenticación requerido

## Archivos Principales

- `lib/api.ts` - Cliente HTTP para la API
- `lib/config.ts` - Configuración de la aplicación
- `lib/interceptors.ts` - Interceptores para tokens JWT
- `hooks/useAuth.ts` - Hook personalizado de autenticación
- `components/auth/ProtectedRoute.tsx` - Componentes de protección de rutas
- `components/auth/LogoutButton.tsx` - Componente de logout
- `app/test-auth/page.tsx` - Página de pruebas de autenticación

## Pruebas

Para probar la funcionalidad, visita `/test-auth` después de iniciar sesión. Esta página permite:

- Ver el estado actual de autenticación
- Probar todos los endpoints de la API
- Ver los datos de respuesta en tiempo real
- Verificar el manejo de errores 