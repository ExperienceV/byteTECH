"use client"

import { useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/hooks/useAuth'

interface ProtectedRouteProps {
  children: React.ReactNode
  redirectTo?: string
  requireAuth?: boolean
  requireSensei?: boolean
}

export function ProtectedRoute({ 
  children, 
  redirectTo = '/login',
  requireAuth = true,
  requireSensei = false 
}: ProtectedRouteProps) {
  const { isAuthenticated, user, isLoading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    // Si está cargando, no hacer nada
    if (isLoading) return

    // Si requiere autenticación y no está autenticado
    if (requireAuth && !isAuthenticated) {
      router.push(redirectTo)
      return
    }

    // Si requiere ser sensei y no lo es
    if (requireSensei && user && !user.is_sensei) {
      router.push('/unauthorized')
      return
    }

    // Si no requiere autenticación y está autenticado, redirigir a home
    if (!requireAuth && isAuthenticated) {
      router.push('/')
      return
    }
  }, [isAuthenticated, user, isLoading, requireAuth, requireSensei, redirectTo, router])

  // Mostrar loading mientras verifica autenticación
  if (isLoading) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-cyan-400 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-slate-400 font-mono text-sm">Verificando autenticación...</p>
        </div>
      </div>
    )
  }

  // Si requiere autenticación y no está autenticado, no mostrar contenido
  if (requireAuth && !isAuthenticated) {
    return null
  }

  // Si requiere ser sensei y no lo es, no mostrar contenido
  if (requireSensei && user && !user.is_sensei) {
    return null
  }

  // Si no requiere autenticación y está autenticado, no mostrar contenido
  if (!requireAuth && isAuthenticated) {
    return null
  }

  return <>{children}</>
}

// Componente para rutas que solo pueden acceder usuarios NO autenticados
export function PublicRoute({ children, redirectTo = '/' }: { children: React.ReactNode, redirectTo?: string }) {
  return (
    <ProtectedRoute requireAuth={false} redirectTo={redirectTo}>
      {children}
    </ProtectedRoute>
  )
}

// Componente para rutas que requieren ser sensei
export function SenseiRoute({ children, redirectTo = '/unauthorized' }: { children: React.ReactNode, redirectTo?: string }) {
  return (
    <ProtectedRoute requireAuth={true} requireSensei={true} redirectTo={redirectTo}>
      {children}
    </ProtectedRoute>
  )
} 