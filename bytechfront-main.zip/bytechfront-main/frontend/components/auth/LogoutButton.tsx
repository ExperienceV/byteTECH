"use client"

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Button } from '@/components/ui/button'
import { LogOut, Loader2 } from 'lucide-react'
import { useAuth } from '@/hooks/useAuth'

interface LogoutButtonProps {
  variant?: 'default' | 'destructive' | 'outline' | 'secondary' | 'ghost' | 'link'
  size?: 'default' | 'sm' | 'lg' | 'icon'
  className?: string
  children?: React.ReactNode
  onLogout?: () => void
}

export function LogoutButton({ 
  variant = 'outline',
  size = 'default',
  className = '',
  children,
  onLogout 
}: LogoutButtonProps) {
  const { logout } = useAuth()
  const router = useRouter()
  const [isLoggingOut, setIsLoggingOut] = useState(false)

  const handleLogout = async () => {
    try {
      setIsLoggingOut(true)
      
      // Llamar a la función de logout del hook
      await logout()
      
      // Callback opcional
      if (onLogout) {
        onLogout()
      }
      
      // Redirigir al login
      router.push('/login')
      
    } catch (error) {
      console.error('Error en logout:', error)
      // Aún así redirigir al login
      router.push('/login')
    } finally {
      setIsLoggingOut(false)
    }
  }

  return (
    <Button
      variant={variant}
      size={size}
      className={className}
      onClick={handleLogout}
      disabled={isLoggingOut}
    >
      {isLoggingOut ? (
        <>
          <Loader2 className="mr-2 h-4 w-4 animate-spin" />
          Cerrando sesión...
        </>
      ) : (
        <>
          <LogOut className="mr-2 h-4 w-4" />
          {children || 'Cerrar sesión'}
        </>
      )}
    </Button>
  )
} 