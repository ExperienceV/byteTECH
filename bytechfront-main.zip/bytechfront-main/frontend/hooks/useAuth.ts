import { useState, useEffect, useCallback } from 'react'
import { authApi, type AuthResponse, type RegisterRequest, type LoginRequest } from '@/lib/api'
import { debugLog } from '@/lib/config'

export interface User {
  id: number
  name: string
  email: string
  is_sensei: boolean
  created_at: string
  updated_at: string
}

export interface AuthState {
  user: User | null
  isAuthenticated: boolean
  isLoading: boolean
  error: string | null
}

export interface UseAuthReturn extends AuthState {
  login: (email: string, password: string) => Promise<boolean>
  register: (data: RegisterRequest) => Promise<boolean>
  logout: () => Promise<void>
  clearError: () => void
  refreshUser: () => Promise<void>
}

// Función helper para obtener usuario desde localStorage
function getUserFromStorage(): User | null {
  if (typeof window === 'undefined') return null
  
  try {
    const stored = localStorage.getItem('bytetech_user')
    if (stored) {
      return JSON.parse(stored)
    }
  } catch (error) {
    console.error('Error parsing user from storage:', error)
    localStorage.removeItem('bytetech_user')
  }
  return null
}

// Función helper para guardar usuario en localStorage
function saveUserToStorage(user: User | null): void {
  if (typeof window === 'undefined') return
  
  if (user) {
    localStorage.setItem('bytetech_user', JSON.stringify(user))
  } else {
    localStorage.removeItem('bytetech_user')
  }
}

export function useAuth(): UseAuthReturn {
  const [state, setState] = useState<AuthState>({
    user: null,
    isAuthenticated: false,
    isLoading: true,
    error: null,
  })

  // Inicializar estado desde localStorage
  useEffect(() => {
    const user = getUserFromStorage()
    setState(prev => ({
      ...prev,
      user,
      isAuthenticated: !!user,
      isLoading: false,
    }))
  }, [])

  // Función para limpiar errores
  const clearError = useCallback(() => {
    setState(prev => ({ ...prev, error: null }))
  }, [])

  // Función para refrescar datos del usuario
  const refreshUser = useCallback(async () => {
    try {
      setState(prev => ({ ...prev, isLoading: true }))
      
      // Por ahora, solo verificamos si hay un usuario en localStorage
      // En el futuro, podríamos hacer una llamada al backend para verificar el token
      const user = getUserFromStorage()
      
      setState(prev => ({
        ...prev,
        user,
        isAuthenticated: !!user,
        isLoading: false,
      }))
    } catch (error) {
      debugLog('❌ Error refreshing user:', error)
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: 'Error al refrescar datos del usuario',
      }))
    }
  }, [])

  // Función de login
  const login = useCallback(async (email: string, password: string): Promise<boolean> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }))
      
      debugLog('🔐 Iniciando login con hook:', { email })
      
      const response = await authApi.login({ email, password })
      
      // Guardar usuario en localStorage
      saveUserToStorage(response.user)
      
      setState(prev => ({
        ...prev,
        user: response.user,
        isAuthenticated: true,
        isLoading: false,
        error: null,
      }))
      
      debugLog('✅ Login exitoso con hook:', response.user)
      return true
      
    } catch (error) {
      debugLog('❌ Error en login con hook:', error)
      
      let errorMessage = 'Error en el login'
      if (error && typeof error === 'object' && 'message' in error) {
        errorMessage = error.message as string
      }
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: errorMessage,
      }))
      
      return false
    }
  }, [])

  // Función de registro
  const register = useCallback(async (data: RegisterRequest): Promise<boolean> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }))
      
      debugLog('🔐 Iniciando registro con hook:', { email: data.email, name: data.name })
      
      const response = await authApi.register(data)
      
      // Guardar usuario en localStorage
      saveUserToStorage(response.user)
      
      setState(prev => ({
        ...prev,
        user: response.user,
        isAuthenticated: true,
        isLoading: false,
        error: null,
      }))
      
      debugLog('✅ Registro exitoso con hook:', response.user)
      return true
      
    } catch (error) {
      debugLog('❌ Error en registro con hook:', error)
      
      let errorMessage = 'Error en el registro'
      if (error && typeof error === 'object' && 'message' in error) {
        errorMessage = error.message as string
      }
      
      setState(prev => ({
        ...prev,
        isLoading: false,
        error: errorMessage,
      }))
      
      return false
    }
  }, [])

  // Función de logout
  const logout = useCallback(async (): Promise<void> => {
    try {
      setState(prev => ({ ...prev, isLoading: true, error: null }))
      
      debugLog('🔐 Iniciando logout con hook')
      
      // Llamar al endpoint de logout del backend
      await authApi.logout()
      
      // Limpiar localStorage
      saveUserToStorage(null)
      
      setState(prev => ({
        ...prev,
        user: null,
        isAuthenticated: false,
        isLoading: false,
        error: null,
      }))
      
      debugLog('✅ Logout exitoso con hook')
      
    } catch (error) {
      debugLog('❌ Error en logout con hook:', error)
      
      // Aún así, limpiar el estado local
      saveUserToStorage(null)
      
      setState(prev => ({
        ...prev,
        user: null,
        isAuthenticated: false,
        isLoading: false,
        error: 'Error en el logout, pero se cerró la sesión local',
      }))
    }
  }, [])

  return {
    ...state,
    login,
    register,
    logout,
    clearError,
    refreshUser,
  }
} 