// Configuración de la aplicación byteTECH

export const config = {
  // URLs de la API
  api: {
    baseUrl: process.env.NEXT_PUBLIC_API_URL || 'http://127.0.0.1:8000',
    timeout: 10000, // 10 segundos
  },
  
  // Configuración de la aplicación
  app: {
    name: 'byteTECH',
    version: '1.0.0',
    description: 'Plataforma de aprendizaje de programación',
  },
  
  // Configuración de autenticación
  auth: {
    cookieName: 'bytetech_auth',
    sessionTimeout: 24 * 60 * 60 * 1000, // 24 horas en milisegundos
  },
  
  // Configuración de desarrollo
  development: {
    enableMockData: process.env.NODE_ENV === 'development',
    enableDebugLogs: process.env.NODE_ENV === 'development',
  }
}

// Función helper para obtener la URL completa de la API
export function getApiUrl(endpoint: string): string {
  return `${config.api.baseUrl}${endpoint}`
}

// Función helper para logging condicional
export function debugLog(...args: any[]) {
  if (config.development.enableDebugLogs) {
    console.log('[DEBUG]', ...args)
  }
}

// Función helper para validar email
export function isValidEmail(email: string): boolean {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
  return emailRegex.test(email)
}

// Función helper para validar contraseña
export function isValidPassword(password: string): boolean {
  return password.length >= 8
} 