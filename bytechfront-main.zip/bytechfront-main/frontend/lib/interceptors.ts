// Interceptores para manejar tokens JWT automáticamente
import { debugLog } from './config'

// Función para obtener el token de acceso desde las cookies
function getAccessToken(): string | null {
  if (typeof document === 'undefined') return null
  
  const cookies = document.cookie.split(';')
  const accessTokenCookie = cookies.find(cookie => 
    cookie.trim().startsWith('access_token=')
  )
  
  if (accessTokenCookie) {
    return accessTokenCookie.split('=')[1]
  }
  
  return null
}

// Función para verificar si un token está expirado
function isTokenExpired(token: string): boolean {
  try {
    const payload = JSON.parse(atob(token.split('.')[1]))
    const currentTime = Math.floor(Date.now() / 1000)
    return payload.exp < currentTime
  } catch (error) {
    debugLog('❌ Error verificando expiración del token:', error)
    return true
  }
}

// Función para refrescar el token
async function refreshAccessToken(): Promise<string | null> {
  try {
    debugLog('🔄 Refrescando token de acceso...')
    
    const response = await fetch('/api/auth/refresh', {
      method: 'POST',
      credentials: 'include',
    })
    
    if (response.ok) {
      debugLog('✅ Token refrescado exitosamente')
      return getAccessToken()
    } else {
      debugLog('❌ Error refrescando token')
      return null
    }
  } catch (error) {
    debugLog('❌ Error en refresh token:', error)
    return null
  }
}

// Interceptor para requests
export async function requestInterceptor(request: Request): Promise<Request> {
  const token = getAccessToken()
  
  if (token && isTokenExpired(token)) {
    debugLog('⚠️ Token expirado, intentando refrescar...')
    const newToken = await refreshAccessToken()
    
    if (newToken) {
      // Crear nueva request con el token refrescado
      const newRequest = new Request(request.url, {
        method: request.method,
        headers: request.headers,
        body: request.body,
        credentials: 'include',
      })
      
      // Agregar el token refrescado si es necesario
      if (!newRequest.headers.has('Authorization')) {
        newRequest.headers.set('Authorization', `Bearer ${newToken}`)
      }
      
      return newRequest
    } else {
      // Si no se puede refrescar, redirigir al login
      debugLog('❌ No se pudo refrescar el token, redirigiendo al login')
      if (typeof window !== 'undefined') {
        window.location.href = '/login'
      }
    }
  }
  
  return request
}

// Interceptor para responses
export async function responseInterceptor(response: Response): Promise<Response> {
  // Si la respuesta es 401 (Unauthorized), intentar refrescar el token
  if (response.status === 401) {
    debugLog('⚠️ Respuesta 401, intentando refrescar token...')
    
    const newToken = await refreshAccessToken()
    if (newToken) {
      // Reintentar la request original con el nuevo token
      const originalRequest = response.headers.get('x-original-request')
      if (originalRequest) {
        const request = JSON.parse(originalRequest)
        const newRequest = new Request(request.url, {
          method: request.method,
          headers: {
            ...request.headers,
            'Authorization': `Bearer ${newToken}`
          },
          body: request.body,
          credentials: 'include',
        })
        
        return fetch(newRequest)
      }
    } else {
      // Si no se puede refrescar, redirigir al login
      debugLog('❌ No se pudo refrescar el token, redirigiendo al login')
      if (typeof window !== 'undefined') {
        window.location.href = '/login'
      }
    }
  }
  
  return response
}

// Función para configurar interceptores globales
export function setupInterceptors(): void {
  if (typeof window === 'undefined') return
  
  // Interceptar fetch globalmente
  const originalFetch = window.fetch
  
  window.fetch = async function(input: RequestInfo | URL, init?: RequestInit): Promise<Response> {
    let request = new Request(input, init)
    
    // Aplicar interceptor de request
    request = await requestInterceptor(request)
    
    // Realizar la request
    let response = await originalFetch.call(this, request)
    
    // Aplicar interceptor de response
    response = await responseInterceptor(response)
    
    return response
  }
  
  debugLog('🔧 Interceptores configurados')
}

// Función para limpiar interceptores
export function cleanupInterceptors(): void {
  if (typeof window === 'undefined') return
  
  // Restaurar fetch original
  if (window.fetch !== fetch) {
    // Nota: Esto es una simplificación, en un caso real necesitarías
    // mantener una referencia al fetch original
    debugLog('🧹 Interceptores limpiados')
  }
} 