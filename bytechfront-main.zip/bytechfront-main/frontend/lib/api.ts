// Configuración de la API de byteTECH
import { config, getApiUrl } from './config'

// Interfaces para las respuestas de la API
export interface RegisterRequest {
  name: string
  email: string
  password: string
  is_sensei?: boolean | null
}     

export interface LoginRequest {
  email: string
  password: string
}

export interface AuthResponse {
  message: string
  user: {
    id: number
    name: string
    email: string
    is_sensei: boolean
    created_at: string
    updated_at: string
  }
}

export interface ApiError {
  detail?: string | Array<{
    loc: string[]
    msg: string
    type: string
  }>
  message?: string
}

// Función helper para manejar errores de la API
function handleApiError(error: any): ApiError {
  if (error.response?.data) {
    return error.response.data
  }
  if (error.message) {
    return { message: error.message }
  }
  return { message: 'Error desconocido' }
}

const apiRequest = async <T>(endpoint: string, options: RequestInit = {}): Promise<T> => {
  const url = `/api${endpoint}`;
  const headers = {
    'Content-Type': 'application/json',
    ...options.headers,
  };
  try {
    const response = await fetch(url, { ...options, headers });
    if (!response.ok) {
      let errorMessage = `HTTP error! status: ${response.status}`;
      try {
        const errorBody = await response.json();
        errorMessage = errorBody.message || errorMessage;
      } catch (e) {}
      throw new Error(errorMessage);
    }
    return response.json() as T;
  } catch (error: any) {
    throw new Error(`API request failed: ${error.message}`);
  }
};

// AUTH API
export const authApi = {
  async register(data: RegisterRequest): Promise<AuthResponse> {
    return apiRequest<AuthResponse>('/auth/register', {
      method: 'POST',
      body: JSON.stringify(data),
      credentials: 'include',
    });
  },
  async login(data: LoginRequest): Promise<AuthResponse> {
    return apiRequest<AuthResponse>('/auth/login', {
      method: 'POST',
      body: JSON.stringify(data),
      credentials: 'include',
    });
  },
  async logout(): Promise<{ message: string }> {
    return apiRequest<{ message: string }>('/auth/logout', {
      method: 'POST',
      credentials: 'include',
    });
  }
};

export interface CourseData {
  id: number
  name: string
  description: string
  price: number
  duration?: string
  students?: number
  rating?: number
  tags?: string[]
  sensei_name?: string
  language?: string
  difficulty?: string
  lessons?: number
  hours?: number
  content?: any[]
}

export interface CourseContentResponse {
  is_paid: boolean
  course_content: CourseData
}

export interface PurchaseResponse {
  checkout_url: string
}

export interface WebhookResponse {
  received: boolean
}

// COURSES API
export const coursesApi = {
  async getMtdCourses(): Promise<{ mtd_courses: CourseData[] }> {
    return apiRequest<{ mtd_courses: CourseData[] }>('/courses/mtd_courses', {
      credentials: 'include',
    });
  },
  async getCourseContent(courseId: number): Promise<CourseContentResponse> {
    return apiRequest<CourseContentResponse>(`/courses/course_content?course_id=${courseId}`, {
      credentials: 'include',
    });
  },
  async buyCourse(courseId: number): Promise<PurchaseResponse> {
    return apiRequest<PurchaseResponse>('/courses/buy_course', {
      method: 'POST',
      body: JSON.stringify({ course_id: courseId }),
      credentials: 'include',
    });
  },
  async getMyCourses(): Promise<CourseData[]> {
    return apiRequest<CourseData[]>('/courses/my_courses', {
      credentials: 'include',
    });
  },
  async stripeWebhook(payload: any, signature: string): Promise<WebhookResponse> {
    return apiRequest<WebhookResponse>('/courses/webhook', {
      method: 'POST',
      body: JSON.stringify(payload),
      headers: {
        'stripe-signature': signature,
      },
      credentials: 'include',
    });
  },
};

export interface Thread {
  id: number
  title: string
  lesson_id?: number
  topic?: string
}

export interface Message {
  id: number
  name: string
  message: string
  thread_id?: number
  user_id?: number
}

// FORUMS API
export const forumsApi = {
  async createThread(thread: { lesson_id: number; topic: string }): Promise<any> {
    return apiRequest<any>('/forums/create_thread/', {
      method: 'POST',
      body: JSON.stringify(thread),
      credentials: 'include',
    });
  },
  async deleteThread(thread_id: number): Promise<any> {
    return apiRequest<any>(`/forums/delete_thread/?thread_id=${thread_id}`, {
      method: 'DELETE',
      credentials: 'include',
    });
  },
  async getThreadsByLesson(lesson_id: number): Promise<{ threads: Thread[]; lesson_id: number; user_id: number }> {
    return apiRequest<{ threads: Thread[]; lesson_id: number; user_id: number }>(`/forums/mtd_threads/?lesson_id=${lesson_id}`, {
      credentials: 'include',
    });
  },
  async sendMessage(msg: { thread_id: number; message: string }): Promise<any> {
    return apiRequest<any>('/forums/send_message/', {
      method: 'POST',
      body: JSON.stringify(msg),
      credentials: 'include',
    });
  },
  async getMessagesByThread(thread_id: number): Promise<{ messages: Message[]; thread_id: number; user_id: number }> {
    return apiRequest<{ messages: Message[]; thread_id: number; user_id: number }>(`/forums/messages_thread/?thread_id=${thread_id}`, {
      credentials: 'include',
    });
  },
};

export interface WorkbrenchCourse {
  course_id: number
  sensei_id: number
  name: string
  description: string
  price: string
  hours: string
  miniature_id: string
}

export interface WorkbrenchCreateResponse {
  Message: string
  mtd_course: WorkbrenchCourse
}

export interface WorkbrenchSectionResponse {
  course_id: number
  section_id: number
}

export interface WorkbrenchLessonRequest {
  section_id: number
  course_id: number
  title: string
  file: File
}

export interface WorkbrenchMetadataRequest {
  course_id: number
  name?: string
  description?: string
  price?: string
  hours?: string
}

// WORKBRENCH API
export const workbrenchApi = {
  async createCourse(formData: FormData): Promise<WorkbrenchCreateResponse> {
    return fetch(getApiUrl('/workbrench/new_course'), {
      method: 'POST',
      body: formData,
      credentials: 'include',
    }).then(res => res.json());
  },
  
  async deleteCourse(courseId: number): Promise<any> {
    return apiRequest<any>(`/workbrench/delete_course/${courseId}`, {
      method: 'DELETE',
      credentials: 'include',
    });
  },
  
  async createSection(courseId: number): Promise<WorkbrenchSectionResponse> {
    return apiRequest<WorkbrenchSectionResponse>(`/workbrench/new_section/${courseId}`, {
      method: 'POST',
      credentials: 'include',
    });
  },
  
  async deleteSection(sectionId: number): Promise<any> {
    return apiRequest<any>(`/workbrench/delete_section/${sectionId}`, {
      method: 'DELETE',
      credentials: 'include',
    });
  },
  
  async createLesson(formData: FormData): Promise<any> {
    return fetch(getApiUrl('/workbrench/add_lesson'), {
      method: 'POST',
      body: formData,
      credentials: 'include',
    }).then(res => res.json());
  },
  
  async deleteLesson(fileId: string, lessonId: number): Promise<any> {
    return apiRequest<any>(`/workbrench/delete_lesson/${fileId}/${lessonId}`, {
      method: 'POST',
      credentials: 'include',
    });
  },
  
  async editMetadata(courseData: WorkbrenchMetadataRequest): Promise<any> {
    return apiRequest<any>('/workbrench/edit_metadata', {
      method: 'POST',
      body: JSON.stringify(courseData),
      credentials: 'include',
    });
  },
  
  async giveCourse(courseId: number, userEmail: string): Promise<any> {
    const formData = new FormData();
    formData.append('course_id', String(courseId));
    formData.append('user_email_to_give', userEmail);
    return fetch(getApiUrl('/workbrench/give_course'), {
      method: 'POST',
      body: formData,
      credentials: 'include',
    }).then(res => res.json());
  },
};

// MEDIA API
export const mediaApi = {
  async downloadFile(file_id: string): Promise<Blob> {
    const url = getApiUrl(`/media/get_file?file_id=${encodeURIComponent(file_id)}`);
    const response = await fetch(url, {
      method: 'GET',
      credentials: 'include',
    });
    if (!response.ok) {
      throw new Error('No se pudo descargar el archivo');
    }
    return response.blob();
  },
}; 

// SUPPORT API
export interface SupportEmailRequest {
  name: string
  mail: string
  issue: string
  message: string
}

export const supportApi = {
  async sendEmail(data: SupportEmailRequest): Promise<{ detail: string }> {
    return apiRequest<{ detail: string }>('/support/send_email', {
      method: 'POST',
      body: JSON.stringify(data),
      credentials: 'include',
    });
  },
};

// Get Users
export const usersApi = {
  async getAllUsers() {
    return apiRequest<any[]>('/auth/get_users', { credentials: 'include' });
  }
} 