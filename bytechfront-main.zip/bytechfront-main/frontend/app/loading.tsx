import { TerminalLoading } from "@//components/terminal-loading"

export default function Loading() {
  return <TerminalLoading />
}
