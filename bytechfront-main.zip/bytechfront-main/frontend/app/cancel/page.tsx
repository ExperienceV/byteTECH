"use client"

import { UniqueHeader } from "@//components/unique-header"
import { UniqueFooter } from "@//components/unique-footer"
import { Button } from "@//components/ui/button"
import { Terminal, XCircle, ArrowLeft, ShoppingCart } from "lucide-react"
import Link from "next/link"

export default function CancelPage() {
  return (
    <div className="min-h-screen bg-dynamic-gradient">
      <UniqueHeader />

      {/* Cancel Section */}
      <section className="bg-slate-950 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-red-900/5 via-transparent to-orange-900/5" />
        <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-12 sm:py-16 relative z-10">
          <div className="max-w-2xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 bg-slate-900/80 backdrop-blur-sm border border-slate-800 rounded-full px-4 py-2 mb-8">
              <Terminal className="w-4 h-4 text-red-400" />
              <span className="text-red-400 text-sm font-mono">./payment --cancelled</span>
            </div>

            <div className="bg-slate-900/80 backdrop-blur-sm border border-red-500/30 rounded-xl p-8 mb-8">
              <div className="w-20 h-20 bg-red-500/20 rounded-full flex items-center justify-center mx-auto mb-6">
                <XCircle className="w-10 h-10 text-red-400" />
              </div>

              <h1 className="font-mono font-bold leading-tight text-white text-3xl sm:text-4xl mb-4">
                {">"} PAGO CANCELADO
              </h1>

              <p className="text-slate-400 font-mono text-lg mb-6">
                El proceso de pago fue cancelado
              </p>

              <div className="bg-red-500/10 border border-red-500/30 rounded-lg p-4 mb-8">
                <p className="text-red-400 font-mono text-sm">
                  ⚠️ No se realizó ningún cargo a tu tarjeta
                </p>
                <p className="text-red-400 font-mono text-sm">
                  ⚠️ El curso no fue agregado a tu biblioteca
                </p>
                <p className="text-red-400 font-mono text-sm">
                  ⚠️ Puedes intentar la compra nuevamente cuando quieras
                </p>
              </div>
            </div>

            <div className="space-y-4">
              <Link href="/courses">
                <Button className="w-full bg-cyan-500 hover:bg-cyan-600 text-black font-semibold py-3 rounded-lg font-mono">
                  <ShoppingCart className="mr-2 h-4 w-4" />
                  VER CURSOS DISPONIBLES
                </Button>
              </Link>

              <Link href="/">
                <Button variant="outline" className="w-full border border-slate-700 text-slate-300 hover:bg-slate-800 font-mono py-3 rounded-lg">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  VOLVER AL INICIO
                </Button>
              </Link>
            </div>

            <div className="mt-8 p-4 bg-slate-900/50 rounded-lg">
              <p className="text-slate-400 font-mono text-xs">
                // ¿Tuviste problemas con el pago? Contacta soporte en{" "}
                <span className="text-cyan-400">soporte@bytetech.dev</span>
              </p>
            </div>
          </div>
        </div>
      </section>

      <UniqueFooter />
    </div>
  )
} 